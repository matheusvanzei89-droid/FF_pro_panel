package com.ffpropanel;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.SharedPreferences;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(12, 17, 29);
    private final int CARD = Color.rgb(25, 35, 52);
    private final int CYAN = Color.rgb(64, 220, 244);
    private final int WHITE = Color.rgb(238, 245, 255);
    private LinearLayout root, content;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        prefs = getSharedPreferences("panel_settings", MODE_PRIVATE);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        setContentView(root);
        header();
        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), dp(12), dp(18), dp(24));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        navigation();
        showHome();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable shape(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void header() {
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(20), dp(18), dp(20), dp(14));
        TextView title = text("FF PRO PANEL", 21, CYAN, true);
        bar.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        TextView ver = text("ANDROID 64-BIT  •  v1.0", 10, 0xff9aacc2, true);
        bar.addView(ver);
        root.addView(bar);
        View line = new View(this); line.setBackgroundColor(0xff26364a);
        root.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
    }

    private void navigation() {
        LinearLayout nav = new LinearLayout(this);
        nav.setPadding(dp(8), dp(8), dp(8), dp(8));
        nav.setBackgroundColor(0xff111b2b);
        String[] names = {"Início", "Mira", "Treino", "Sistema"};
        for (int i=0;i<names.length;i++) {
            final int page=i;
            TextView b = text(names[i], 12, WHITE, true);
            b.setGravity(Gravity.CENTER);
            b.setPadding(dp(4), dp(12), dp(4), dp(12));
            b.setOnClickListener(v -> {
                if(page==0) showHome();
                if(page==1) showAim();
                if(page==2) showTraining();
                if(page==3) showSystem();
            });
            nav.addView(b, new LinearLayout.LayoutParams(0, -2, 1));
        }
        root.addView(nav);
    }

    private void clear(String title, String subtitle) {
        content.removeAllViews();
        addText(title, 23, WHITE, true);
        addText(subtitle, 13, 0xff9aacc2, false);
        space(14);
    }

    private void addText(String s, int size, int color, boolean bold) {
        content.addView(text(s,size,color,bold));
    }

    private void space(int h) {
        View v = new View(this);
        content.addView(v, new LinearLayout.LayoutParams(1, dp(h)));
    }

    private LinearLayout card(String title, String desc) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16),dp(14),dp(16),dp(14));
        box.setBackground(shape(CARD,16,0xff30465f));
        TextView t = text(title,16,CYAN,true);
        TextView d = text(desc,12,0xffc1ccda,false);
        d.setPadding(0,dp(6),0,0);
        box.addView(t); box.addView(d);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2);
        lp.bottomMargin=dp(12); content.addView(box,lp);
        return box;
    }

    private void showHome() {
        clear("Painel principal", "Seu espaço de configurações e treinamento");
        card("🎯  Treinamento de mira", "Pratique sua precisão em um alvo interativo.");
        card("⚙️  Sensibilidade", "Salve seus próprios ajustes e consulte quando quiser.");
        card("🫧  Menu rápido", "Atalhos dentro do aplicativo, sem interferir em outros apps.");
        card("📱  Sistema", "Veja informações básicas do seu dispositivo.");
        Button go = button("ABRIR TREINAMENTO");
        go.setOnClickListener(v -> showTraining());
        content.addView(go, full());
        space(8);
        addText("Aviso: este painel é independente e não modifica o Free Fire.",11,0xff8295ad,false);
    }

    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setTextColor(0xff07121d);
        b.setTextSize(12); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        b.setBackground(shape(CYAN,12,0));
        return b;
    }
    private LinearLayout.LayoutParams full() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2);
        p.topMargin=dp(8); p.bottomMargin=dp(8); return p;
    }

    private void showAim() {
        clear("Configurações de mira", "Ajustes pessoais para consulta e treino");
        String[] labels = {"Geral", "Ponto vermelho", "Mira 2x", "Mira 4x", "AWM", "Olhadinha"};
        for(String label: labels) {
            addText(label,14,WHITE,true); space(3);
            int val=prefs.getInt(label, 50);
            TextView value=text(val+" / 100",12,CYAN,true);
            content.addView(value);
            SeekBar seek=new SeekBar(this); seek.setMax(100); seek.setProgress(val);
            seek.setProgressTintList(android.content.res.ColorStateList.valueOf(CYAN));
            seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
                public void onProgressChanged(SeekBar s,int p,boolean u){value.setText(p+" / 100");}
                public void onStartTrackingTouch(SeekBar s){}
                public void onStopTrackingTouch(SeekBar s){prefs.edit().putInt(label,s.getProgress()).apply();}
            });
            content.addView(seek,full());
        }
        Button reset=button("RESTAURAR PADRÕES");
        reset.setOnClickListener(v->{for(String l:labels)prefs.edit().putInt(l,50).apply();showAim();});
        content.addView(reset,full());
        addText("Os valores são apenas anotações locais; não são aplicados automaticamente ao jogo.",11,0xff8295ad,false);
    }

    private void showTraining() {
        clear("Treinamento de precisão", "Toque no alvo quantas vezes conseguir");
        final TextView score=text("Acertos: 0",18,WHITE,true);
        content.addView(score); space(12);
        final FrameLayout arena=new FrameLayout(this);
        arena.setBackground(shape(0xff101d30,18,0xff30465f));
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,dp(340));
        content.addView(arena,ap);
        final TextView target=text("＋",34,0xff07121d,true);
        target.setGravity(Gravity.CENTER);
        target.setBackground(shape(CYAN,100,0));
        FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(dp(64),dp(64));
        tp.gravity=Gravity.CENTER; arena.addView(target,tp);
        final int[] hits={0};
        target.setOnClickListener(v->{
            hits[0]++; score.setText("Acertos: "+hits[0]);
            int maxX=Math.max(0,arena.getWidth()-dp(64));
            int maxY=Math.max(0,arena.getHeight()-dp(64));
            FrameLayout.LayoutParams p=(FrameLayout.LayoutParams)target.getLayoutParams();
            p.leftMargin=(int)(Math.random()*Math.max(1,maxX));
            p.topMargin=(int)(Math.random()*Math.max(1,maxY));
            p.gravity=Gravity.TOP|Gravity.LEFT; target.setLayoutParams(p);
        });
        Button reset=button("ZERAR CONTAGEM");
        reset.setOnClickListener(v->{hits[0]=0;score.setText("Acertos: 0");});
        content.addView(reset,full());
        addText("Dica: tente tocar no centro do alvo com rapidez e precisão.",12,0xff9aacc2,false);
    }

    private void showSystem() {
        clear("Sistema", "Informações deste aparelho");
        card("Dispositivo", android.os.Build.MANUFACTURER+" "+android.os.Build.MODEL);
        card("Android", android.os.Build.VERSION.RELEASE+" (API "+android.os.Build.VERSION.SDK_INT+")");
        card("Arquitetura", android.os.Build.SUPPORTED_ABIS.length>0?android.os.Build.SUPPORTED_ABIS[0]:"Não identificada");
        card("Sobre", "FF PRO PANEL • versão 1.0\nAplicativo independente para treinamento e configurações pessoais.");
    }
}
