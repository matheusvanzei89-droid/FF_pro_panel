# FF PRO PANEL

Projeto Android nativo em Java, com interface escura/neon.

## Recursos
- Tela inicial e navegação
- Preferências locais de sensibilidade (anotações; não alteram o jogo)
- Mini treinamento de mira com alvo interativo e contador
- Menu de navegação rápido dentro do app
- Informações do dispositivo

## Gerar APK pela nuvem (sem computador)

1. Crie ou entre em uma conta em https://github.com/
2. Crie um repositório novo (pode ser privado).
3. Envie **todo o conteúdo desta pasta** para o repositório, mantendo a pasta `.github/workflows`.
4. No GitHub, abra a aba **Actions** e aguarde o workflow "Build FF PRO PANEL APK" terminar.
   - Também é possível abrir o workflow e tocar em **Run workflow**.
5. Quando aparecer como concluído, abra a execução e baixe o artefato **FF-PRO-PANEL-debug**.
6. Extraia o ZIP do artefato e instale `app-debug.apk` no Android. O Android poderá pedir autorização para instalar apps dessa fonte.

## Requisitos de compilação
O workflow configura automaticamente:
- JDK 17
- Gradle 8.7
- Android SDK 35
- Android Gradle Plugin 8.6.1

Este pacote contém o código-fonte e a automação de compilação; não contém um APK já compilado. O APK só será produzido depois que o workflow executar com sucesso no GitHub.

O app é independente e não modifica o Free Fire. Não inclui bypass, cheat, modificação de memória ou interação com o jogo.
